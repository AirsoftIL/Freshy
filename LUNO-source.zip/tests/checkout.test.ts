import { test } from 'node:test';
import assert from 'node:assert/strict';
import * as checkout from '../lib/checkout.ts';
void test('checkout derives prices from the server catalog and rejects malformed quantities', () => {
  const quote = checkout.validateCheckout({
    items: [
      { productId: 'classic', quantity: 2, price: 1 },
      { productId: 'extreme', quantity: 1 },
    ],
  });
  assert.equal(quote.total, 109700);
  assert.equal(quote.currency, 'ILS');
  for (const value of [
    null,
    {},
    { items: [] },
    { items: [{ productId: 'wrong', quantity: 1 }] },
    { items: [{ productId: 'classic', quantity: 0 }] },
    { items: [{ productId: 'classic', quantity: 1.5 }] },
    { items: [{ productId: 'classic', quantity: 100 }] },
  ])
    assert.throws(() => checkout.validateCheckout(value));
});
void test('checkout rejects duplicate product rows instead of silently changing the order', () => {
  assert.throws(() =>
    checkout.validateCheckout({
      items: [
        { productId: 'classic', quantity: 1 },
        { productId: 'classic', quantity: 2 },
      ],
    }),
  );
});
