import { test } from 'node:test';
import assert from 'node:assert/strict';
import * as store from '../lib/store.ts';

void test('cart accumulates models and calculates exact prices', () => {
  let cart = store.changeQuantity([], 'classic', 2);
  cart = store.changeQuantity(cart, 'extreme', 1);
  assert.equal(store.cartTotal(cart), 109700);
  assert.equal(store.cartCount(cart), 3);
  assert.equal(
    store.cartTotal(store.changeQuantity(cart, 'classic', 1)),
    74800,
  );
  assert.deepEqual(store.changeQuantity(cart, 'classic', 0), [
    { productId: 'extreme', quantity: 1 },
  ]);
});

void test('restored cart rejects invalid data and consolidates duplicates safely', () => {
  assert.deepEqual(store.sanitizeCart(null), []);
  assert.deepEqual(
    store.sanitizeCart([
      { productId: 'missing', quantity: 2 },
      { productId: 'classic', quantity: -1 },
      { productId: 'extreme', quantity: 1.5 },
    ]),
    [],
  );
  assert.deepEqual(
    store.sanitizeCart([
      { productId: 'classic', quantity: 2 },
      { productId: 'classic', quantity: 3 },
    ]),
    [{ productId: 'classic', quantity: 5 }],
  );
  assert.deepEqual(
    store.sanitizeCart([{ productId: 'extreme', quantity: 200 }]),
    [{ productId: 'extreme', quantity: 99 }],
  );
});

void test('order inquiry includes accurate models, quantities and destination', () => {
  const url = new URL(
    store.orderInquiryUrl([
      { productId: 'classic', quantity: 2 },
      { productId: 'extreme', quantity: 1 },
    ]),
  );
  assert.equal(url.hostname, 'wa.me');
  assert.equal(url.pathname, '/972542266696');
  assert.match(url.searchParams.get('text')!, /Classic.*2/);
  assert.match(url.searchParams.get('text')!, /1,097|1097/);
});
