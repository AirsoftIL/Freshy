# LUNO — SEE BEYOND.

להוראות הפעלה ועריכה בעברית: `START-HERE.md`.

Hebrew RTL smart-eyewear storefront. Classic ₪349; Extreme Edition ₪399. Dark lunar brand direction, responsive catalog, product details, persistent cart, team orders, WhatsApp and FAQ.

## Run

`npm install`, then `npm run dev`. Production: `npm run build`. Validation: `npm run lint`, `npx tsc --noEmit`, `node --experimental-strip-types --test tests/*.test.ts`.

Product prices and WhatsApp destination: `lib/store.ts`. Homepage: `components/storefront.tsx`. Responsive theme: `app/globals.css`. Payment handoff: `docs/grow-integration.md`.

Lint checks authored application code. Untouched generated Shadcn components and the generated mobile hook are excluded because the starter's own accessibility/compiler lint rules flag those vendored files.

GROW is deliberately disabled until merchant code and configuration arrive. Cart inquiries open a prefilled WhatsApp message for the visitor to send. They are not paid or confirmed orders. Images use supplied references; the lunar hero is an AI-assisted atmosphere image, and Classic was isolated from the supplied screenshot. Image prompts and source provenance are in `docs/assets.md`.
