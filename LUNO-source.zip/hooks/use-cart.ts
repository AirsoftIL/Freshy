'use client';
import {
  useSyncExternalStore,
  type Dispatch,
  type SetStateAction,
} from 'react';
import { CART_STORAGE_KEY, sanitizeCart, type CartItem } from '@/lib/store';

const emptyCart: CartItem[] = [];
let cachedCart: CartItem[] = emptyCart;
let cachedRaw: string | null = null;
let memoryOnly = false;
const eventName = 'luno-cart-updated';

function getSnapshot() {
  if (memoryOnly) return cachedCart;
  try {
    const raw = localStorage.getItem(CART_STORAGE_KEY);
    if (raw !== cachedRaw) {
      cachedRaw = raw;
      try {
        cachedCart = sanitizeCart(JSON.parse(raw || '[]'));
      } catch {
        cachedCart = [];
      }
    }
  } catch {
    memoryOnly = true;
  }
  return cachedCart;
}
function subscribe(callback: () => void) {
  const onStorage = (event: StorageEvent) => {
    if (event.key === CART_STORAGE_KEY || event.key === null) callback();
  };
  window.addEventListener('storage', onStorage);
  window.addEventListener(eventName, callback);
  return () => {
    window.removeEventListener('storage', onStorage);
    window.removeEventListener(eventName, callback);
  };
}
const setCart: Dispatch<SetStateAction<CartItem[]>> = (update) => {
  const current = getSnapshot();
  cachedCart = sanitizeCart(
    typeof update === 'function' ? update(current) : update,
  );
  cachedRaw = JSON.stringify(cachedCart);
  try {
    localStorage.setItem(CART_STORAGE_KEY, cachedRaw);
  } catch {
    memoryOnly = true;
  }
  window.dispatchEvent(new Event(eventName));
};
export function useCart() {
  const cart = useSyncExternalStore(subscribe, getSnapshot, () => emptyCart);
  return [cart, setCart] as const;
}
