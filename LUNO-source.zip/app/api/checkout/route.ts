import { validateCheckout } from '@/lib/checkout';
import { growProvider } from '@/lib/payments/grow';

const json = (value: unknown, status = 200) =>
  Response.json(value, { status, headers: { 'Cache-Control': 'no-store' } });
export async function GET() {
  return json({ available: growProvider.isConfigured(), provider: 'grow' });
}
export async function POST(request: Request) {
  const origin = request.headers.get('origin');
  if (origin && origin !== new URL(request.url).origin)
    return json({ message: 'הבקשה אינה מורשית.' }, 403);
  if (!request.headers.get('content-type')?.includes('application/json'))
    return json({ message: 'יש לשלוח נתוני סל תקינים.' }, 415);
  if (Number(request.headers.get('content-length') || 0) > 4096)
    return json({ message: 'הבקשה גדולה מדי.' }, 413);
  let quote;
  try {
    const raw = await request.text();
    if (new TextEncoder().encode(raw).length > 4096)
      return json({ message: 'הבקשה גדולה מדי.' }, 413);
    quote = validateCheckout(JSON.parse(raw));
  } catch {
    return json(
      { message: 'פרטי הסל אינם תקינים. עדכנו את הכמויות ונסו שוב.' },
      400,
    );
  }
  if (!growProvider.isConfigured())
    return json(
      {
        code: 'PAYMENT_NOT_CONFIGURED',
        message:
          'התשלום המקוון אינו זמין כרגע. ניתן להמשיך את ההזמנה בוואטסאפ.',
      },
      503,
    );
  try {
    const session = await growProvider.createSession(quote);
    if (new URL(session.url).protocol !== 'https:')
      throw new Error('Invalid payment redirect');
    return json(session);
  } catch {
    return json(
      {
        message:
          'לא ניתן להתחיל את התשלום כרגע. נסו שוב או פנו אלינו בוואטסאפ.',
      },
      502,
    );
  }
}
