import type { Metadata, Viewport } from 'next';
import './globals.css';
import './refinements.css';
import './mobile.css';

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  viewportFit: 'cover',
  themeColor: '#0b0c0c',
};
export const metadata: Metadata = {
  metadataBase: new URL(
    'https://luno-smart-eyewear.hadar013015312.chatgpt.site',
  ),
  title: 'LUNO — לראות מעבר | משקפיים חכמים',
  description:
    'קלאס בעיר, עוצמה בשטח. LUNO Classic ו־Extreme Edition: מצלמת 8MP, וידאו 1080p, שמע אישי ו־AI, בתוך המשקפיים שלכם.',
  icons: { icon: '/favicon.svg' },
  openGraph: {
    title: 'LUNO — SEE BEYOND.',
    description: 'הכול מתחיל במבט.',
    locale: 'he_IL',
    type: 'website',
  },
};
export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="he" dir="rtl" className="dark">
      <body>{children}</body>
    </html>
  );
}
