'use client';
import { useEffect, useRef, useState } from 'react';
import Image from 'next/image';
import { useCart } from '@/hooks/use-cart';
import {
  ArrowLeft,
  ArrowUpLeft,
  AudioLines,
  BatteryFull,
  Camera,
  ChevronDown,
  Globe2,
  Menu,
  MessageCircle,
  Mic,
  Minus,
  Mountain,
  Plus,
  ShoppingBag,
  Sparkles,
  Truck,
  Users,
  X,
} from 'lucide-react';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import {
  Sheet,
  SheetClose,
  SheetContent,
  SheetDescription,
  SheetTitle,
} from '@/components/ui/sheet';
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  MAX_QUANTITY,
  cartCount,
  cartTotal,
  changeQuantity,
  findProduct,
  formatPrice,
  orderInquiryUrl,
  products,
  whatsappUrl,
  type Product,
  type ProductId,
} from '@/lib/store';

const features = [
  {
    icon: Camera,
    title: 'הרגע שלכם. בחדות מלאה.',
    detail: 'מצלמת 8MP · וידאו 1080p',
    label: 'CAPTURE',
  },
  {
    icon: AudioLines,
    title: 'הסאונד הולך איתכם.',
    detail: 'מוזיקה ושיחות, ישירות לאוזניים',
    label: 'LISTEN',
  },
  {
    icon: Sparkles,
    title: 'עוד דרך לראות את העולם.',
    detail: 'זיהוי בזמן אמת · AI עם ChatGPT',
    label: 'DISCOVER',
  },
  {
    icon: BatteryFull,
    title: 'מוכנים להמשך הדרך.',
    detail: 'עד 4 שעות צילום רצופות',
    label: 'KEEP GOING',
  },
];
const questions = [
  [
    'תוך כמה זמן המשקפיים מגיעים?',
    'זמן המשלוח הוא 4–7 ימי עסקים ממועד אישור ההזמנה. פרטי המסירה ועלות המשלוח יתואמו בעת ההזמנה.',
  ],
  [
    'כמה זמן הסוללה מחזיקה?',
    'עד 4 שעות צילום רצופות. משך השימוש בפועל עשוי להשתנות לפי ההגדרות והשימוש במצלמה, בשמע ובתכונות החכמות.',
  ],
  [
    'מה ההבדל בין Classic ל־Extreme Edition?',
    'שני הדגמים מגיעים בצבע שחור וכוללים מצלמת 8MP, צילום וידאו 1080p, מיקרופון, רמקול ותכונות AI. דגם Classic מציע מסגרת קלאסית ליום־יום; Extreme Edition מציע עיצוב ספורטיבי עוטף לשטח ולחיים בתנועה.',
  ],
  [
    'למה לבחור ב־LUNO?',
    'LUNO הוא מותג ישראלי עם דרישות ייצור המוגדרות במיוחד עבורו. בחירת החומרים ותכנון הדגמים נעשים מתוך מחשבה על שימוש יומיומי אינטנסיבי — מהעיר ועד השטח — תוך תשומת לב לעמידות, לנוחות ולעיצוב.',
  ],
  [
    'מה אפשר לעשות עם ה־AI?',
    'המשקפיים כוללים תכונות AI עם ChatGPT וזיהוי בזמן אמת, לצד צילום, מוזיקה ושיחות. לפני ההזמנה נשמח להסביר על האפליקציה, החיבור לטלפון והתאימות למכשיר שלכם.',
  ],
  [
    'אפשר להזמין כמות למחלקה, לפלוגה או לצוות?',
    'בהחלט. כתבו לנו בוואטסאפ עם הדגם והכמות המבוקשת, ונחזור אליכם עם הצעה מרוכזת ופרטי אספקה שמתאימים לצוות שלכם.',
  ],
];
function Brand({ footer = false }: { footer?: boolean }) {
  return (
    <a
      href="#top"
      className={`brand ${footer ? 'brand-footer' : ''}`}
      aria-label="LUNO — לעמוד הבית"
    >
      <Image
        unoptimized
        src="/images/luno-logo.jpeg"
        alt="LUNO — SEE BEYOND."
        width="1254"
        height="305"
      />
    </a>
  );
}
export default function Storefront() {
  const [cart, setCart] = useCart();

  const [cartOpen, setCartOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [selected, setSelected] = useState<Product | null>(null);
  const [announcement, setAnnouncement] = useState('');
  const [checkoutError, setCheckoutError] = useState('');
  const [checkoutBusy, setCheckoutBusy] = useState(false);
  const [onlinePayment, setOnlinePayment] = useState(false);
  const bagRef = useRef<HTMLButtonElement>(null);
  const detailRef = useRef<HTMLButtonElement | null>(null);
  useEffect(() => {
    const controller = new AbortController();
    fetch('/api/checkout', { signal: controller.signal })
      .then((response) => response.json())
      .then((data) =>
        setOnlinePayment(
          !!data &&
            typeof data === 'object' &&
            'available' in data &&
            data.available === true,
        ),
      )
      .catch(() => {});
    return () => controller.abort();
  }, []);
  function addProduct(id: ProductId) {
    setCart((current) =>
      changeQuantity(
        current,
        id,
        (current.find((item) => item.productId === id)?.quantity || 0) + 1,
      ),
    );
    setSelected(null);
    setCartOpen(true);
    setCheckoutError('');
    setAnnouncement(`${findProduct(id)!.name} נוסף לסל`);
  }
  async function checkout() {
    setCheckoutBusy(true);
    setCheckoutError('');
    try {
      const response = await fetch('/api/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ items: cart }),
      });
      const data = (await response.json()) as {
        url?: string;
        message?: string;
      };
      if (!response.ok || typeof data.url !== 'string')
        throw new Error(
          typeof data.message === 'string'
            ? data.message
            : 'לא ניתן להתחיל את התשלום כרגע. נסו שוב או פנו אלינו בוואטסאפ.',
        );
      const url = new URL(data.url);
      if (url.protocol !== 'https:')
        throw new Error('לא התקבל קישור תשלום תקין. פנו אלינו בוואטסאפ.');
      window.location.assign(url.toString());
    } catch (error) {
      setCheckoutError(
        error instanceof Error ? error.message : 'אירעה תקלה. נסו שוב.',
      );
    } finally {
      setCheckoutBusy(false);
    }
  }
  return (
    <>
      <a className="skip-link" href="#main">
        דלגו לתוכן
      </a>
      <div id="top" className="shipping-banner">
        <span className="status-dot" />
        משלוח עד אליכם · 4–7 ימי עסקים
        <span className="banner-signature" dir="ltr">
          SEE BEYOND.
        </span>
      </div>
      <header className="site-header">
        <div className="header-inner">
          <Brand />
          <nav className="desktop-nav" aria-label="ניווט ראשי">
            <a href="#collection">הדגמים שלנו</a>
            <a href="#technology">הטכנולוגיה</a>
            <a href="#about">הסיפור של LUNO</a>
            <a href="#faq">שאלות ותשובות</a>
          </nav>
          <div className="header-actions">
            <button
              ref={bagRef}
              className="cart-toggle"
              onClick={() => setCartOpen(true)}
              aria-label={`סל קניות, ${cartCount(cart)} פריטים`}
            >
              <ShoppingBag size={19} />
              <span className="cart-label">הסל שלי</span>
              <span className="cart-count">{cartCount(cart)}</span>
            </button>
            <button
              className="mobile-menu icon-button"
              aria-label="פתיחת תפריט"
              onClick={() => setMenuOpen(true)}
            >
              <Menu size={22} />
            </button>
          </div>
        </div>
      </header>
      <main id="main">
        <section className="hero" aria-labelledby="hero-title">
          <Image
            unoptimized
            className="hero-image"
            src="/images/luno-hero.png"
            alt="משקפי LUNO Extreme שחורים על סלע כהה, עם ירח ברקע — תמונת אווירה"
            width="1672"
            height="941"
            fetchPriority="high"
          />
          <div className="hero-shade" />
          <div className="hero-inner container">
            <div className="hero-copy">
              <div className="eyebrow">
                <span />
                SMART EYEWEAR. NEW PERSPECTIVE.
              </div>
              <h1 id="hero-title">
                הכול מתחיל
                <br />
                <span>במבט.</span>
              </h1>
              <p>
                מצלמה. מוזיקה. בינה מלאכותית.
                <br />
                כל מה שצריך, בתוך המשקפיים שלכם. הכירו את LUNO.
              </p>
              <div className="hero-actions">
                <a className="button button-light" href="#collection">
                  לגלות את הדגמים
                  <ArrowLeft size={18} />
                </a>
              </div>
              <div className="hero-note">
                <span className="small-cross">+</span> שני דגמים. נקודת מבט
                חדשה.
              </div>
            </div>
          </div>
          <div className="hero-bottom container">
            <a href="#collection" className="scroll-cue">
              <ChevronDown size={16} />
              הסיפור שלכם מתחיל כאן
            </a>
            <div className="hero-product-label" dir="ltr">
              <span>01 /</span> EXTREME EDITION
              <span className="label-line" />
            </div>
          </div>
        </section>
        <section
          id="technology"
          className="technology"
          aria-label="הטכנולוגיה של LUNO"
        >
          <div className="feature-grid container">
            {features.map(({ icon: Icon, title, detail, label }) => (
              <div className="feature" key={label}>
                <Icon strokeWidth={1.3} size={27} />
                <div>
                  <h2>{title}</h2>
                  <p>{detail}</p>
                </div>
              </div>
            ))}
          </div>
        </section>
        <section
          id="collection"
          className="collection section-space container"
          aria-labelledby="collection-title"
        >
          <div className="section-topline">
            <span className="eyebrow">FIND YOUR LUNO</span>
            <span className="section-index" dir="ltr">
              THE COLLECTION / 01
            </span>
          </div>
          <div className="section-heading">
            <div>
              <h2 id="collection-title" className="sr-only">
                הדגמים שלנו
              </h2>
              <p>מהיום־יום ועד השטח. בחרו את ה־LUNO שלכם.</p>
            </div>
            <span className="collection-note">שני דגמים. שחור אחד.</span>
          </div>
          <div className="products-grid">
            {products.map((product) => (
              <article
                className={`product-card product-${product.id}`}
                key={product.id}
              >
                <button
                  className="product-visual"
                  aria-label={`הצגת פרטים על ${product.name}`}
                  onClick={(event) => {
                    detailRef.current = event.currentTarget;
                    setSelected(product);
                  }}
                >
                  <span className="product-category">
                    {product.id === 'classic'
                      ? 'הקלאסיקה החדשה'
                      : 'לחיים בתנועה'}
                  </span>
                  <span className="product-number" dir="ltr">
                    {product.id === 'classic' ? '01' : '02'} / LUNO
                  </span>
                  <Image
                    unoptimized
                    src={product.image}
                    alt={`משקפיים חכמים LUNO ${product.name} בצבע שחור`}
                    width={1536}
                    height={1024}
                    loading="lazy"
                  />
                  <span className="view-product">
                    מבט מקרוב
                    <Plus size={16} />
                  </span>
                </button>
                <div className="product-info">
                  <div className="product-title-row">
                    <div>
                      <p className="product-edition" dir="ltr">
                        {product.edition}
                      </p>
                      <h3 dir="ltr">{product.name}</h3>
                    </div>
                    <span className="price" dir="ltr">
                      {formatPrice(product.price)}
                    </span>
                  </div>
                  <p className="product-tagline">{product.tagline}</p>
                  <div className="product-specs">
                    <span>8MP / 1080p</span>
                    <span>AI + ChatGPT</span>
                    <span>שמע ושיחות</span>
                  </div>
                  <div className="product-bottom">
                    <button
                      className="button button-product"
                      onClick={() => addProduct(product.id)}
                    >
                      הוספה לסל
                      <Plus size={18} />
                    </button>
                    <span className="color-option">
                      <span />
                      שחור
                    </span>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </section>
        <section
          id="about"
          className="about-section"
          aria-labelledby="about-title"
        >
          <div className="container about-grid">
            <div className="about-copy">
              <span className="eyebrow">REFINED IN STYLE. READY FOR LIFE.</span>
              <h2 id="about-title">
                סטייל בעיר.
                <br />
                <span>אופי של שטח.</span>
              </h2>
              <p>
                LUNO נולד מתוך מחשבה פשוטה: הטכנולוגיה הכי טובה היא זו שמשתלבת
                בחיים שלכם.
              </p>
              <p>
                מותג ישראלי שמחבר בין עיצוב מדויק, חומרים שנבחרו בקפידה ודרישות
                ייצור משלנו. בדרך לעבודה, ברכיבה או בשטח — כדי שתוכלו להיות
                ברגע, וגם לקחת אותו איתכם.
              </p>
              <a className="text-link" href="#collection">
                למצוא את הדגם שלכם
                <ArrowLeft size={18} />
              </a>
            </div>
            <div className="brand-statement">
              <div className="moon-mark">
                <Image
                  unoptimized
                  src="/images/luno-moon.jpeg"
                  alt="סמל הירח של LUNO"
                  width="1179"
                  height="836"
                  loading="lazy"
                />
              </div>
            </div>
          </div>
          <div className="container use-cases">
            <span>
              <Globe2 size={18} />
              ביום־יום
            </span>
            <span>
              <Mountain size={19} />
              בשטח
            </span>
            <span>
              <AudioLines size={19} />
              בתנועה
            </span>
            <span>
              <Mic size={18} />
              בכל שיחה
            </span>
          </div>
        </section>
        <section id="teams" className="team-section container">
          <div className="team-icon">
            <Users size={33} strokeWidth={1.2} />
          </div>
          <div className="team-copy">
            <span className="eyebrow">BETTER TOGETHER</span>
            <h2>כל המחלקה רוצה להתפנק?</h2>
            <p>
              מזמינים למחלקה, לפלוגה או לקבוצת הרכיבה?
              <br />
              נדאג לכם להצעה שמתאימה לכמות ולצוות.
            </p>
          </div>
          <a
            className="button button-light"
            href={whatsappUrl(
              'היי LUNO, אני מעוניין בהזמנה מרוכזת למחלקה / פלוגה / צוות. אשמח לקבל הצעה לכמות.',
            )}
            target="_blank"
            rel="noopener noreferrer"
          >
            בואו נדבר על כמות
            <MessageCircle size={19} />
          </a>
        </section>
        <section
          id="faq"
          className="faq-section section-space container"
          aria-labelledby="faq-title"
        >
          <div className="faq-heading">
            <span className="eyebrow">GOOD TO KNOW</span>
            <h2 id="faq-title">
              עוד קצת
              <br />
              לפני שיוצאים.
            </h2>
            <p>התשובות לדברים שרציתם לדעת.</p>
            <a
              className="text-link"
              href={whatsappUrl('היי LUNO, יש לי שאלה לגבי המשקפיים.')}
              target="_blank"
              rel="noopener noreferrer"
            >
              יש שאלה נוספת?
              <ArrowUpLeft size={17} />
            </a>
          </div>
          <Accordion className="faq-list">
            {questions.map(([question, answer], index) => (
              <AccordionItem key={question} value={index} className="faq-item">
                <AccordionTrigger className="faq-trigger">
                  <span className="faq-number">0{index + 1}</span>
                  <span>{question}</span>
                </AccordionTrigger>
                <AccordionContent className="faq-answer">
                  {answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </section>
      </main>
      <footer className="site-footer">
        <div className="container footer-top">
          <div>
            <Brand footer />
            <p>לראות. לשמוע. להיות ברגע.</p>
          </div>
          <nav aria-label="קישורי תחתית">
            <a href="#collection">הדגמים שלנו</a>
            <a href="#about">הסיפור שלנו</a>
            <a href="#faq">שאלות ותשובות</a>
            <a
              href={whatsappUrl('היי LUNO, אשמח לקבל פרטים.')}
              target="_blank"
              rel="noopener noreferrer"
            >
              דברו איתנו
              <MessageCircle size={15} />
            </a>
          </nav>
          <a className="footer-phone" href="tel:+972542266696" dir="ltr">
            054-226-6696
            <ArrowUpLeft size={18} />
          </a>
        </div>
        <div className="container footer-bottom">
          <span>© {new Date().getFullYear()} LUNO. כל הזכויות שמורות.</span>
          <span dir="ltr">INTELLIGENT. ESSENTIAL. TIMELESS.</span>
          <a href="#top">בחזרה למעלה ↑</a>
        </div>
      </footer>
      <a
        className="floating-contact"
        href={whatsappUrl('היי LUNO, אשמח לעזרה בבחירת משקפיים.')}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="דברו עם LUNO בוואטסאפ"
      >
        <MessageCircle size={23} />
        <span>כאן בשבילכם</span>
      </a>
      <output className="sr-only" aria-live="polite">
        {announcement}
      </output>
      <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
        <SheetContent
          side="right"
          className="mobile-nav-panel"
          showCloseButton={false}
        >
          <div className="panel-top">
            <SheetTitle>נקודת המבט שלכם</SheetTitle>
            <SheetClose className="icon-button" aria-label="סגירת התפריט">
              <X />
            </SheetClose>
          </div>
          <SheetDescription>גלו את LUNO</SheetDescription>
          <nav aria-label="תפריט מובייל">
            {[
              ['#collection', 'הדגמים שלנו'],
              ['#technology', 'הטכנולוגיה'],
              ['#about', 'הסיפור של LUNO'],
              ['#teams', 'הזמנות לצוותים'],
              ['#faq', 'שאלות ותשובות'],
            ].map(([href, text]) => (
              <a key={href} href={href} onClick={() => setMenuOpen(false)}>
                {text}
                <ArrowLeft size={18} />
              </a>
            ))}
          </nav>
        </SheetContent>
      </Sheet>
      <Sheet open={cartOpen} onOpenChange={setCartOpen}>
        <SheetContent
          side="left"
          className="cart-panel"
          showCloseButton={false}
          finalFocus={bagRef}
        >
          <div className="panel-top">
            <SheetTitle className="panel-title">
              הסל שלכם <span>({cartCount(cart)})</span>
            </SheetTitle>
            <SheetClose className="icon-button" aria-label="סגירת הסל">
              <X size={22} />
            </SheetClose>
          </div>
          <SheetDescription className="panel-description">
            נקודת המבט החדשה שלכם, ממש כאן.
          </SheetDescription>
          {cart.length === 0 ? (
            <div className="cart-empty">
              <ShoppingBag size={48} strokeWidth={1} />
              <h3>הסל עדיין ריק.</h3>
              <p>ה־LUNO הבא שלכם מחכה לכם.</p>
              <button
                className="button button-light"
                onClick={() => {
                  setCartOpen(false);
                  document
                    .getElementById('collection')
                    ?.scrollIntoView({ behavior: 'smooth' });
                }}
              >
                לגלות את הדגמים
                <ArrowLeft size={18} />
              </button>
            </div>
          ) : (
            <>
              <div className="cart-items">
                {cart.map((item) => {
                  const product = findProduct(item.productId)!;
                  return (
                    <article className="cart-item" key={item.productId}>
                      <Image
                        unoptimized
                        src={product.image}
                        alt={product.name}
                        width="120"
                        height="100"
                      />
                      <div className="cart-item-content">
                        <div className="cart-item-heading">
                          <h3 dir="ltr">{product.name}</h3>
                          <button
                            className="icon-button remove-item"
                            aria-label={`הסרת ${product.name} מהסל`}
                            onClick={() =>
                              setCart((current) =>
                                changeQuantity(current, item.productId, 0),
                              )
                            }
                          >
                            <X size={16} />
                          </button>
                        </div>
                        <p>שחור · {formatPrice(product.price)} ליחידה</p>
                        <div className="cart-item-bottom">
                          <div className="quantity-control" dir="ltr">
                            <button
                              aria-label={`הפחתת כמות ${product.name}`}
                              onClick={() =>
                                setCart((current) =>
                                  changeQuantity(
                                    current,
                                    item.productId,
                                    item.quantity - 1,
                                  ),
                                )
                              }
                            >
                              <Minus size={15} />
                            </button>
                            <output aria-label={`כמות ${product.name}`}>
                              {item.quantity}
                            </output>
                            <button
                              disabled={item.quantity >= MAX_QUANTITY}
                              aria-label={`הגדלת כמות ${product.name}`}
                              onClick={() =>
                                setCart((current) =>
                                  changeQuantity(
                                    current,
                                    item.productId,
                                    item.quantity + 1,
                                  ),
                                )
                              }
                            >
                              <Plus size={15} />
                            </button>
                          </div>
                          <strong>
                            {formatPrice(product.price * item.quantity)}
                          </strong>
                        </div>
                      </div>
                    </article>
                  );
                })}
              </div>
              <div className="cart-summary">
                <div className="total-row">
                  <span>סכום המוצרים</span>
                  <strong>{formatPrice(cartTotal(cart))}</strong>
                </div>
                <p className="shipping-note">
                  <Truck size={17} />
                  משלוח: 4–7 ימי עסקים. העלות תתואם בהזמנה.
                </p>
                {onlinePayment ? (
                  <button
                    className="button button-light checkout-button"
                    disabled={checkoutBusy}
                    onClick={checkout}
                  >
                    {checkoutBusy ? 'מכינים את התשלום…' : 'למעבר לתשלום מאובטח'}
                    <ArrowLeft size={18} />
                  </button>
                ) : (
                  <a
                    className="button button-light checkout-button"
                    href={orderInquiryUrl(cart)}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    להמשך הזמנה בוואטסאפ
                    <MessageCircle size={19} />
                  </a>
                )}
                {checkoutError && (
                  <p className="checkout-error" role="alert">
                    {checkoutError}
                  </p>
                )}
                {onlinePayment && checkoutError && (
                  <a
                    className="text-link"
                    href={orderInquiryUrl(cart)}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    להמשך בוואטסאפ
                    <ArrowLeft size={16} />
                  </a>
                )}
                <p className="checkout-note">
                  {onlinePayment
                    ? 'תועברו לעמוד תשלום מאובטח.'
                    : 'פרטי הסל יעברו להודעה שתוכלו לשלוח לנו. ההזמנה תאושר בשיחה.'}
                </p>
              </div>
            </>
          )}
        </SheetContent>
      </Sheet>
      <Dialog
        open={selected !== null}
        onOpenChange={(open) => {
          if (!open) setSelected(null);
        }}
      >
        <DialogContent
          className="product-dialog"
          showCloseButton={false}
          finalFocus={detailRef}
        >
          {selected && (
            <>
              <DialogClose
                className="icon-button detail-close"
                aria-label="סגירת פרטי המוצר"
              >
                <X size={23} />
              </DialogClose>
              <div className="detail-visual">
                <Image
                  unoptimized
                  src={selected.image}
                  alt={`LUNO ${selected.name}`}
                  width="600"
                  height="450"
                />
              </div>
              <div className="detail-copy">
                <span className="eyebrow">{selected.edition}</span>
                <DialogTitle className="detail-title" dir="ltr">
                  {selected.name}
                </DialogTitle>
                <DialogDescription className="detail-description">
                  {selected.description}
                </DialogDescription>
                <p className="detail-audience">{selected.audience}</p>
                <ul className="detail-specs">
                  <li>
                    <Camera size={18} />
                    מצלמת 8MP · וידאו 1080p
                  </li>
                  <li>
                    <AudioLines size={18} />
                    מיקרופון ורמקול מובנים
                  </li>
                  <li>
                    <Sparkles size={18} />
                    AI עם ChatGPT וזיהוי בזמן אמת
                  </li>
                  <li>
                    <BatteryFull size={18} />
                    עד 4 שעות צילום רצופות
                  </li>
                </ul>
                <div className="detail-purchase">
                  <strong>{formatPrice(selected.price)}</strong>
                  <span className="color-option">
                    <span />
                    שחור
                  </span>
                </div>
                <button
                  className="button button-light"
                  onClick={() => addProduct(selected.id)}
                >
                  להוסיף לסל
                  <Plus size={18} />
                </button>
                <p className="detail-shipping">
                  <Truck size={16} />
                  משלוח בתוך 4–7 ימי עסקים
                </p>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
