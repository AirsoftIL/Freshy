import type { CheckoutQuote } from '../checkout';

export type PaymentSession = { url: string; sessionId: string };
export interface PaymentProvider {
  isConfigured(): boolean;
  createSession(quote: CheckoutQuote): Promise<PaymentSession>;
}

/**
 * GROW integration boundary. Replace only this adapter after receiving the
 * merchant's integration code. Keep credentials on the server and use the
 * supplied quote; never accept browser prices. Enable isConfigured only after
 * payment creation and verified, idempotent webhook handling are implemented.
 */
export const growProvider: PaymentProvider = {
  isConfigured: () => false,
  async createSession() {
    throw new Error(
      'התשלום המקוון אינו זמין כרגע. ניתן להמשיך את ההזמנה בוואטסאפ.',
    );
  },
};
