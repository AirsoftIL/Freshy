export type ProductId = 'classic' | 'extreme';
export type CartItem = { productId: ProductId; quantity: number };
export type Product = {
  id: ProductId;
  name: string;
  price: number;
  image: string;
  tagline: string;
  description: string;
  edition: string;
  audience: string;
};
// Prices are integer agorot; authoritative catalog shared by server and UI.
export const products: Product[] = [
  {
    id: 'classic',
    name: 'Classic',
    price: 34900,
    image: '/images/classic-studio.png',
    tagline: 'נוכחות שקטה. אפשרויות חדשות.',
    description:
      'הקווים הנקיים שאתם אוהבים, עם הטכנולוגיה שאתם רוצים. מצלמה, מוזיקה, שיחות ו־AI במסגרת שחורה שמשתלבת בטבעיות ביום שלכם.',
    edition: 'EVERYDAY, ELEVATED.',
    audience: 'ליום־יום, לעבודה ולכל מה שביניהם',
  },
  {
    id: 'extreme',
    name: 'Extreme Edition',
    price: 39900,
    image: '/images/extreme-studio.png',
    tagline: 'בשביל הרגעים שלא עוצרים.',
    description:
      'עיצוב ספורטיבי עוטף, נוכחות חדה וטכנולוגיה בהישג קול. לחוויות בשטח, לרכיבות ולימים שהופכים לסיפור טוב.',
    edition: 'BUILT FOR YOUR NEXT.',
    audience: 'לשטח, לרכיבה ולחיים בתנועה',
  },
];
export const MAX_QUANTITY = 99;
export const CART_STORAGE_KEY = 'luno-cart-v1';
export const WHATSAPP_NUMBER = '972542266696';
export const findProduct = (id: string) =>
  products.find((product) => product.id === id);
export const formatPrice = (agorot: number) =>
  new Intl.NumberFormat('he-IL', {
    style: 'currency',
    currency: 'ILS',
    maximumFractionDigits: 0,
  }).format(agorot / 100);
export function sanitizeCart(value: unknown): CartItem[] {
  if (!Array.isArray(value)) return [];
  const result: CartItem[] = [];
  for (const item of value.slice(0, 200)) {
    if (
      !item ||
      typeof item !== 'object' ||
      !findProduct(item.productId) ||
      !Number.isInteger(item.quantity) ||
      item.quantity <= 0
    )
      continue;
    const existing = result.find((row) => row.productId === item.productId);
    if (existing)
      existing.quantity = Math.min(
        MAX_QUANTITY,
        existing.quantity + item.quantity,
      );
    else
      result.push({
        productId: item.productId,
        quantity: Math.min(MAX_QUANTITY, item.quantity),
      });
  }
  return result;
}
export function changeQuantity(
  cart: CartItem[],
  productId: ProductId,
  quantity: number,
): CartItem[] {
  if (!findProduct(productId) || !Number.isInteger(quantity))
    return sanitizeCart(cart);
  const filtered = sanitizeCart(cart).filter(
    (item) => item.productId !== productId,
  );
  if (quantity > 0)
    filtered.push({ productId, quantity: Math.min(quantity, MAX_QUANTITY) });
  return products.flatMap((product) =>
    filtered.filter((item) => item.productId === product.id),
  );
}
export const cartCount = (cart: CartItem[]) =>
  sanitizeCart(cart).reduce((total, item) => total + item.quantity, 0);
export const cartTotal = (cart: CartItem[]) =>
  sanitizeCart(cart).reduce(
    (total, item) => total + findProduct(item.productId)!.price * item.quantity,
    0,
  );
export const whatsappUrl = (message: string) =>
  `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
export function orderInquiryUrl(cart: CartItem[]) {
  const clean = sanitizeCart(cart);
  return whatsappUrl(
    [
      'היי LUNO, אשמח להתקדם עם ההזמנה הבאה:',
      ...clean.map(
        (item) =>
          `${findProduct(item.productId)!.name} × ${item.quantity} — ${formatPrice(findProduct(item.productId)!.price * item.quantity)}`,
      ),
      `סה״כ מוצרים: ${formatPrice(cartTotal(clean))}`,
      'אשמח לאישור זמינות, עלות משלוח ופרטי תשלום.',
    ].join('\n'),
  );
}
