import { findProduct, MAX_QUANTITY, type CartItem } from './store.ts';
export type CheckoutQuote = {
  items: CartItem[];
  currency: 'ILS';
  total: number;
};
export function validateCheckout(body: unknown): CheckoutQuote {
  if (
    !body ||
    typeof body !== 'object' ||
    !('items' in body) ||
    !Array.isArray(body.items) ||
    body.items.length < 1 ||
    body.items.length > 2
  )
    throw new Error('בחרו לפחות דגם אחד להזמנה.');
  const seen = new Set<string>();
  const items: CartItem[] = body.items.map((item) => {
    if (
      !item ||
      typeof item !== 'object' ||
      !findProduct(item.productId) ||
      !Number.isInteger(item.quantity) ||
      item.quantity < 1 ||
      item.quantity > MAX_QUANTITY ||
      seen.has(item.productId)
    )
      throw new Error('פרטי הסל אינם תקינים. עדכנו את הכמויות ונסו שוב.');
    seen.add(item.productId);
    return { productId: item.productId, quantity: item.quantity };
  });
  return {
    items,
    currency: 'ILS',
    total: items.reduce(
      (sum, item) => sum + findProduct(item.productId)!.price * item.quantity,
      0,
    ),
  };
}
