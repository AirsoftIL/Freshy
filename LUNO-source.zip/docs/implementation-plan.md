# LUNO storefront

Build the approved Hebrew smart-eyewear store in the empty project. Use black, silver and white, the supplied identity, a cinematic moon/product hero, and original product references. Classic costs ₪349; Extreme Edition costs ₪399. Preserve the user's 8MP / 1080p / four-hour recording / 4–7 business-day shipping specifications over conflicting screenshot text.

1. Implement the RTL homepage, shared theme and brand/product assets. Include product selection, feature explanations, field positioning, bulk WhatsApp contact and FAQs. Use the existing Sheet, Dialog and Accordion primitives for accessible interactions.
2. Test and implement a validated persistent shopping cart: add, remove, change quantity, accurate integer-agorot totals and sanitization of stored data. Build product details and cart views around that shared module.
3. Add a server checkout boundary that recomputes prices from the catalog, accepts only product IDs and quantities, and returns an explicit unavailable response until a GROW provider is installed. Keep provider credentials server-side. Offer a user-clicked WhatsApp order inquiry in the current storefront; no payment collection or confirmed orders.
4. Run behavior tests, TypeScript, lint and production build. Validate server responses and asset loading without browser testing, which was not requested. Publish the complete version privately and show the resulting URL.

Shipping price, returns, warranty, waterproof ratings and certifications were not supplied, so do not invent them. Shipping cost is confirmed in the order conversation. Do not add fake testimonials, discounts or urgency.
