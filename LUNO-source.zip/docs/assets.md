# Image sources

- `public/images/extreme.jpeg`: original user-supplied Extreme product photograph, unchanged.
- `public/images/luno-logo.jpeg` and `luno-moon.jpeg`: original user-supplied branding, unchanged. CSS inverts these for the dark page.
- `public/images/classic-original.jpeg`: original user-supplied Classic screenshot, retained for reference.
- `public/images/classic.png`: isolated from the Classic screenshot with the built-in image generator. No new product design was requested.
- `public/images/luno-hero.png`: built-in image generator using the supplied Extreme photograph as the product identity reference. Used as an atmosphere image, with an explanatory Hebrew alt description.

## Requested studio revision

- `public/images/classic-studio.png`: built-in imagegen edit of `classic.png`. Preserve the exact product, clear lenses, arms, camera and angle; replace the background with a smooth graphite slab, dark charcoal studio and soft silver rim light. Center the entire glasses with room for a 1.75:1 catalog crop. No new logo or text.
- `public/images/extreme-studio.png`: built-in imagegen edit of the original `extreme.jpeg`. Preserve the wraparound frame, shield lens, camera, controls, arms and angle; replace the background with dark basalt and a restrained olive-charcoal studio. Center the entire glasses with room for a 1.75:1 catalog crop. No new logo or text.

The studio revisions are used consistently in product cards, product details and the cart. Original reference images remain available in the project.

## Original hero prompt

Cinematic 16:9 landscape website hero photograph for premium smart sports eyewear. Preserve the reference black angular wraparound lens shield, frame silhouette, front camera, nose support, broad smart arms and earpieces. Place very large glasses across the left 55% and lower middle on rugged charcoal stone. A realistic illuminated cratered partial moon sits behind the upper-left. Keep the rightmost 40% almost black with quiet negative space for Hebrew text. Low-key studio photography, fine cool silver rim light, natural material detail and contact shadows. No text, logos, watermark, UI, humans or fantasy embellishments.

## Classic isolation prompt

Extract only the large main black smart eyeglasses from the upper-middle of the supplied screenshot. Preserve the rounded-square frame, clear lenses, bridge, nose pads, opened smart arms, curved earpieces, controls, charging contacts and camera placement, in the same three-quarter perspective. Keep the entire pair centered on pure white in 3:2 with modest margins and a subtle natural shadow. Remove phone UI, text, cable, small sample glasses, thumbnails and illustrative blue camera glow. Do not redesign or add product details, logos or accessories.
